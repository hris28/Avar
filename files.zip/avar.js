// avar.js

// All campaign data, grouped by section
const data = {

  // Great Houses: original twelve + cadet/post-cataclysm branches
  houses: {
    original: [
      {
        name: "Khol", circle: "1st Circle", circleTag: "gold",
        motto: '"The Foundation Endures"', sigil: "Four-Leaf Clover", sigilTag: "green",
        power: "Economic; trade routes; noble marriages",
        members: "Midas Khol (head); Secus Domitae (married in); Mithe (bastard, secret)",
        disposition: "Quiet, patient, far-reaching",
        notes: "Midas is a covert operator running a long game. Old friends with the late Duke. Biological father of Mithe — known only to Midas. Gave Valerian an hourglass pendant at the Duke's funeral."
      },
      {
        name: "Da'varre", circle: "1st Circle", circleTag: "gold",
        motto: '"Through Still Waters, Truth"', sigil: "Glass Prism / Mirrors", sigilTag: "blue",
        power: "Archive; pre-cataclysm relics; truth-seeking",
        members: "Count Alren (last of the line)",
        disposition: "Isolated, scholarly, haunted",
        notes: "NOT one of the original 12 — cadet branch of a lost original house. Gloamspire: tower on a cavern lake, halls lit by mirrors that glow when truth is spoken. Alren's last letter: 'loyalties I cannot speak of.'"
      },
      {
        name: "Lanvar", circle: "1st Circle", circleTag: "gold",
        motto: "Unknown", sigil: "—", sigilTag: "",
        power: "Dealmaking; alliance brokering",
        members: "Unknown",
        disposition: "Perpetual junior partner",
        notes: "Eternal deal-brokers; rarely act alone."
      },
      {
        name: "Sadin", circle: "1st Circle", circleTag: "gold",
        motto: "Unknown", sigil: "—", sigilTag: "",
        power: "Military; honorable service",
        members: "Unknown",
        disposition: "Honor-bound",
        notes: "Military and honor culture. One of the clearer 'good' houses."
      },
      {
        name: "Vostin", circle: "1st Circle", circleTag: "gold",
        motto: "Unknown", sigil: "—", sigilTag: "",
        power: "Deep mining monopoly",
        members: "Unknown",
        disposition: "Essential; leverage via resources",
        notes: "Controls deep mining operations. Their resources give them leverage over almost every other house."
      },
      {
        name: "Relkan", circle: "1st Circle", circleTag: "gold",
        motto: "Unknown", sigil: "—", sigilTag: "",
        power: "Imperial banking",
        members: "Unknown",
        disposition: "Creditor to all",
        notes: '"Every house owes Relkan." Financial leverage across the entire empire.'
      },
      {
        name: "Velthara", circle: "1st Circle", circleTag: "gold",
        motto: "Unknown", sigil: "—", sigilTag: "",
        power: "Pre-cataclysm relics; surface expeditions",
        members: "Unknown",
        disposition: "Relic hunters; surface-focused",
        notes: "Organize surface expeditions. Control access to pre-cataclysm artifacts."
      },
      {
        name: "Rayne", circle: "1st Circle", circleTag: "gold",
        motto: "Unknown", sigil: "—", sigilTag: "",
        power: "Infrastructure; trade routes; arbitration",
        members: "Unknown",
        disposition: "Neutral arbiters",
        notes: "Build and maintain imperial infrastructure. Neutral enough to arbitrate disputes."
      },
      {
        name: "Calder", circle: "1st Circle", circleTag: "gold",
        motto: "Unknown", sigil: "—", sigilTag: "",
        power: "Intelligence networks",
        members: "Unknown",
        disposition: "Rivals Korvath",
        notes: "Spy networks and intelligence apparatus. Long rivalry with Korvath."
      },
      {
        name: "Korvath", circle: "1st Circle", circleTag: "gold",
        motto: "Unknown", sigil: "—", sigilTag: "",
        power: "Assassination; enforcement",
        members: "Unknown",
        disposition: "Rivals Calder",
        notes: "Wet-works and enforcement arm of noble politics."
      },
      {
        name: "Branneth", circle: "1st–2nd Circle", circleTag: "gold",
        motto: "Unknown", sigil: "—", sigilTag: "",
        power: "Church; Inquisition pipeline",
        members: "Unknown",
        disposition: "Church-aligned",
        notes: "Produces most priests and inquisitors. Deep Church ties."
      },
      {
        name: "Mournen", circle: "1st / 6th Circle", circleTag: "gold",
        motto: '"Heavy Doth the Crown"', sigil: "Red Fist", sigilTag: "red",
        power: "Zen'tar dynastic control; cadet branch = Bluefist",
        members: "Duke (deceased); Prince (missing, ~23-24 yrs old)",
        disposition: "Retreated from Capital politics; bound to the city",
        notes: "The late Duke brought Zen'tar to prominence. Cadet branch = Order of the Blue Fist. Duke's death (Year 618) left the Prince missing and the city in crisis."
      },
      {
        name: "[Name Stricken]", circle: "1st Circle — EXPUNGED", circleTag: "red",
        motto: "—", sigil: "EXPUNGED", sigilTag: "red",
        power: "Led the Great Schism",
        members: "Bloodline ended; lands redistributed",
        disposition: "Attempted to assert noble dominance over Church",
        notes: "Fell during the Great Schism in the years of the Great Martyred Lady. Erased as a lesson."
      },
      {
        name: "[Records Sealed]", circle: "1st Circle — EXPUNGED", circleTag: "red",
        motto: "—", sigil: "EXPUNGED", sigilTag: "red",
        power: "Unknown",
        members: "Bloodline ended",
        disposition: '"Direct opposition to the Church\'s mandate"',
        notes: "Details sealed by Inquisitorial decree. Too dangerous to preserve. Second of the two purged houses."
      },
    ],
    cadet: [
      {
        name: "Domitae", circle: "3rd Circle / 1st via Khol marriage", circleTag: "blue",
        sigil: "Dextra / Sinetra (right/left divisions)", sigilTag: "grey",
        power: "3rd circle noble influence; mineral wells (4th circle)",
        members: "Father: Magus; Mother: Julia. Secus (married into Khol). Decima (heretic).",
        disposition: "Quiet expansion through marriage and resource control",
        notes: "Secus married into House Khol; is organizing a coup of Zen'tar's regency. Quartus runs a 4th circle mineral well. Sister Nona may have been killed by Velintra. Decima is their 10th child."
      },
      {
        name: "Maelis", circle: "3rd Circle", circleTag: "blue",
        sigil: "Elven symbol (right shoulder)", sigilTag: "grey",
        power: "3rd circle noble house; elven connections",
        members: "Unknown",
        disposition: "Actively destabilizing Zen'tar succession",
        notes: "Aids Da'varre, Lanvar, and Sadin. High elf representative seen circling the Duke's funeral. Wants succession contested."
      },
      {
        name: "Morren", circle: "Unknown / 6th via Selka", circleTag: "grey",
        sigil: "—", sigilTag: "",
        power: "Auditor position; formerly merchant-guild aligned",
        members: "Selka Morren (Lady Factor, Auditor)",
        disposition: "Leverage via auditing authority",
        notes: "Selka holds unique authority: full immunity in the Yearning Mines. Accused by Marshall of using a heretic."
      },
      {
        name: "Voss", circle: "Unknown / Pre-cataclysm", circleTag: "grey",
        sigil: "Burn-mark sigil (Proto-Elvish Fragment 8C)", sigilTag: "red",
        power: "Unknown — appears in Fragment 8C",
        members: "Unknown",
        disposition: "Possible internal sabotage / containment breach (pre-cataclysm era)",
        notes: "Sigil appears on Fragment 8C discussing dwarven portal relocation. Suggests a proto-elvish house involved in inter-dimensional activities before the Cataclysm."
      },
      {
        name: "Gulfen / Trinton", circle: "Unknown", circleTag: "grey",
        sigil: "Trident variant", sigilTag: "blue",
        power: "Unknown",
        members: "Unknown",
        disposition: "—",
        notes: "Two noble houses with trident heraldry. The trident sigil appears on the stronghold Ryo glimpsed inside the Wyrm's mindscape."
      },
    ]
  },

  // Organizations grouped by category
  orgs: {
    criminal: [
      {
        name: "Consortium / Concierge", circle: "6th Circle", circleTag: "blue",
        type: "Criminal Syndicate", typeTag: "red",
        sigil: "Elven sigil of Mithris",
        members: "Mithris (founder, dead); Caldun (enforcer)",
        notes: "Multi-level criminal network including Blue Pirates. Sought awakened metals, artifacts, political leverage. Fractured after Mithris's death (~Year 625). The oilcloth package passed to Caldun almost certainly contained the green ledger."
      },
      {
        name: "Blue Pirates", circle: "6th Circle", circleTag: "blue",
        type: "Criminal / Paramilitary", typeTag: "red",
        sigil: "Blue Maritime Motif",
        members: "Mithris (deceased); current leader unknown",
        notes: "Controls lower harbor and certain Zen'tar districts. Hate Arthur Augustus. Largely fractured post-Mithris. The Sunken Croc is their front."
      },
    ],
    military: [
      {
        name: "Militarum", circle: "Empire-wide", circleTag: "gold",
        type: "Military", typeTag: "gold",
        sigil: "Colored armbands by rank/unit",
        members: "The Marshall (Zen'tar); Colonel Zahn",
        notes: "Official Vo'dyn military. Controls outer walls and Yearning Mines in Zen'tar. Martial law declared with 7th Fleet's arrival."
      },
      {
        name: "7th Fleet (The Martyr)", circle: "6th Circle (docked)", circleTag: "blue",
        type: "Naval", typeTag: "blue",
        sigil: "Sigil of Him on each ship",
        members: "Admiral Galewind; Commodore Sal'vin (Hell's Fury)",
        notes: "Most storied fleet — survived the Cataclysm. The Martyr is the flagship (600+ years old, pre-cataclysm galleon). Under Nautica Liticus. Unexpected arrival triggered martial law."
      },
      {
        name: "Penal Outriders / Penitant Deathriders", circle: "6th Circle+", circleTag: "blue",
        type: "Penal Military", typeTag: "grey",
        sigil: "Gray banner, crimson red drops; bone-white helmets",
        members: "Founded from the legacy of Ser Gavriel Val'Tan",
        notes: "Each rider earns one unread pardon for an impossible charge. Recite oath at Gavriel's plinth before each mission. Seen in Zen'tar for the first time in decades."
      },
      {
        name: "Militia", circle: "6th Circle", circleTag: "blue",
        type: "Ad-Hoc City Levy", typeTag: "grey",
        sigil: "—",
        members: "Zenzar/Xanthran (leader, missing ~7 years)",
        notes: "City levy of Zen'tar. Non-functional since Zenzar vanished. Nobody could replace him. Secus Domitae is now trying to purchase Zenzar for a coup."
      },
      {
        name: "Order of the Blue Fist (House Bluefist)", circle: "1st Circle", circleTag: "gold",
        type: "Military Order / Noble House", typeTag: "gold",
        sigil: "Blue Fist / Blue Hand Glove with Crest",
        members: "Hathor (Military Adjudicant); Ulric Ironfist (associated)",
        notes: "Cadet branch of House Mournen. Not associated with priesthood. Hathor may be the masked Establishment Leader who arranged Zenzar's sale to Secus."
      },
    ],
    religious: [
      {
        name: "Inquisition", circle: "Empire-wide", circleTag: "gold",
        type: "Religious Enforcement", typeTag: "red",
        sigil: "Rosettes (new: magic-key; old: engraved power) / Brown Robes",
        members: "Rarik Ville (inquisitor in Zen'tar)",
        notes: "Enforce tithe, suppress heresy. Can execute anyone regardless of noble status. Sub-branch: Witchers. The Bazaar is one of their few directly governed mixed-race locations."
      },
      {
        name: "Luminary Council", circle: "2nd Circle HQ", circleTag: "gold",
        type: "Arcane Authority", typeTag: "purple",
        sigil: "Secreted membership sigil",
        members: "Archmage Liora; formerly Relyssa Daen (disgraced)",
        notes: "Leading authority on magical theory. Rumored founded by the Great Martyred Lady. Secreted membership. Offshoot chapter (Society of Brilliance) active in Zen'tar."
      },
      {
        name: "Auditors", circle: "Empire-wide", circleTag: "gold",
        type: "Imperial Oversight", typeTag: "gold",
        sigil: "—",
        members: "Selka Morren (6th Circle)",
        notes: "Noble-appointed oversight body. Full immunity inside Yearning Mines — the only check on the Marshall's authority there beyond the head of city (currently absent)."
      },
    ],
    paladin: [
      {
        name: "Order Kronos", circle: "Unknown / Church-associated", circleTag: "grey",
        type: "Paladin Order", typeTag: "purple",
        sigil: "Clear Blank Crest",
        members: "Unknown",
        notes: "Possesses oathblades. Extremely reclusive — recently withdrawn and less active externally."
      },
      {
        name: "Order of the Flame", circle: "Unknown / Nearly wiped out", circleTag: "grey",
        type: "Paladin Order", typeTag: "purple",
        sigil: "Pendant (glows near great evil)",
        members: "Aldred (one of the only survivors)",
        notes: "Neutral paladin order. Possessed 4 oathblades. Was eradicating the Aperations. Aldred entered the pentagram first — the only survivor, woke with sword bloodied, amulet glowing red."
      },
      {
        name: "Order of the Rose", circle: "Unknown / Covert", circleTag: "grey",
        type: "Covert Intelligence Order", typeTag: "purple",
        sigil: "Rose-sealed wax orders",
        members: "Crane (master, dead — killed by Caldun); Artemis (operative, now with party)",
        notes: "Hidden order operating on the 'scaffolding' philosophy. Caldun broke from fighting Arthur mid-combat specifically to kill Crane. Motto: 'We're not heroes. We're scaffolding.'"
      },
      {
        name: "The Aperations", circle: "Unknown / Eradicated wherever found", circleTag: "grey",
        type: "Cult", typeTag: "red",
        sigil: "Pentagram association",
        members: "Unknown",
        notes: "Cultist order being eradicated by Order of the Flame. Connected to a dark entity."
      },
    ],
    civil: [
      {
        name: "City Guard / Magistrate", circle: "6th Circle only", circleTag: "blue",
        type: "Civil Policing", typeTag: "gold",
        sigil: "—",
        members: "Garth (Deputy Sergeant); Arthur Augustus (Major Investigator)",
        notes: "Keeps peace. Noble-funded. Suffered a terrorist attack and reeling. Reports to noble faction."
      },
      {
        name: "Investigators (4th Wing)", circle: "6th Circle only", circleTag: "blue",
        type: "Intelligence / Investigation", typeTag: "gold",
        sigil: "—",
        members: "Arthur Augustus (Major); Lantis (Junior, missing/likely dead); Boltin Crestfyre (Lt.)",
        notes: "Ad hoc unit within Zen'tar. Not a formal Vo'dyn institution. Do not touch merchants (Charter of Commerce)."
      },
      {
        name: "Council of Regency", circle: "6th Circle only", circleTag: "blue",
        type: "Political", typeTag: "gold",
        sigil: "—",
        members: "Unknown members; Selka Morren (Auditor appointee)",
        notes: "Rules Zen'tar after the Duke's death. Short-term focused. Possibly involved in the Duke's death. Struggling to hold authority with martial law in effect."
      },
      {
        name: "Dustwalkers", circle: "Inter-circle routes", circleTag: "gold",
        type: "Military / Guard", typeTag: "grey",
        sigil: "—",
        members: "Unknown",
        notes: "Guards in iron robes, silent and still. Patrol tunnel routes between circles."
      },
    ]
  },

  // NPCs grouped by origin/importance category
  npcs: {
    capital: [
      {
        name: "Midas Khol", circle: "1st Circle", role: "Head of House Khol", allegiance: "House Khol; personal long game",
        sigil: "Four-Leaf Clover", status: "Alive",
        notes: "Covert operator. Old adventuring friends with the late Duke. Biological father of Mithe (known only to Midas). Gave Valerian the hourglass pendant at the Duke's funeral: 'I'll keep the hourglass turning.'"
      },
      {
        name: "Duke of Zen'tar", circle: "1st Circle seat / 6th domain", role: "Former ruler of Zen'tar", allegiance: "House Mournen",
        sigil: "Red Fist", status: "Dead (Year 618)",
        notes: "Brought Zen'tar to prominence. Found or obtained the green ledger — possibly killed for/by it. No viewing at his funeral. The Council of Regency is suspected to have had something to do with his death."
      },
      {
        name: "The Prince", circle: "1st Circle heir", role: "Missing heir of Zen'tar", allegiance: "House Mournen",
        sigil: "—", status: "Missing ~7 years",
        notes: "Disappeared ~same time as Zenzar (militia leader). Midas sent Valerian to watch him. Overheard in Session 3: 'The prince will be secured.' Nobody has seen him."
      },
      {
        name: "Valerian Than'dal", circle: "Unknown", role: "Knight; Midas's agent", allegiance: "House Khol / Midas",
        sigil: "Hourglass pendant (given by Midas)", status: "Alive; location unknown",
        notes: "Assigned by Midas to watch the Prince at the Duke's funeral. Received the hourglass pendant."
      },
      {
        name: "Count Alren Da'varre", circle: "1st Circle", role: "Head of House Da'varre; last of the line", allegiance: "House Da'varre; possibly Mithe",
        sigil: "Glass Prism", status: "Alive (reportedly)",
        notes: "Last known blood of a lost Original 12 house. Lost his children, brother Alden, nieces. His last letter: 'loyalties I cannot speak of' and 'the still water.' Legal guardian of Mithe."
      },
      {
        name: "Hathor", circle: "1st Circle / posted to 6th", role: "Military Adjudicant; possibly masked Establishment Leader", allegiance: "Order of the Blue Fist / House Mournen",
        sigil: "Blue hand glove with crest", status: "Alive; active in Zen'tar",
        notes: "Encountered on the caravan road: 'We know and saw the enemy, ash and dust.' The masked Establishment Leader in Session 5 — who arranged Zenzar's sale to Secus — is likely Hathor."
      },
      {
        name: "Secus Domitae", circle: "1st Circle (via Khol marriage)", role: "Coup organizer", allegiance: "House Khol; personal ambition",
        sigil: "—", status: "Alive; active in Zen'tar",
        notes: "2nd child of House Domitae. Trained in cloak-and-dagger. Married into House Khol. Organizing a coup of Zen'tar's Council of Regency. Purchasing Zenzar. Branded Decima in Session 5."
      },
    ],
    zentar: [
      {
        name: "Arthur Augustus", circle: "6th Circle", role: "Major Investigator", allegiance: "Nobles / Magistrate",
        sigil: "—", status: "Alive; crippled (legs)",
        notes: "Noble-born. Killed Mithris ~Year 625 in single combat; cost him the use of his legs. Blue Pirates fractured after that night. Target of 'next hit prince loyalists and Arthur' (Secus, Session 5)."
      },
      {
        name: "Garth", circle: "6th Circle", role: "Deputy Sergeant in Arms", allegiance: "Magistrate / whoever holds power",
        sigil: "—", status: "Alive",
        notes: "'Keeps his job regardless of who holds power.' Wants to impress 'first circlers.' Sided with the nobles over the Marshall's mine jurisdiction."
      },
      {
        name: "Lantis", circle: "6th Circle", role: "Junior Investigator", allegiance: "Arthur / Magistrate",
        sigil: "—", status: "Missing; likely dead",
        notes: "Half-elf. Good heart; commoner background. Frequented the Sunken Croc. The Marshall was in contact with him — suspicious. Possibly Mithris's child (player theory)."
      },
      {
        name: "Rarik Ville", circle: "6th Circle (Inquisitor)", role: "Head Justice / suspected Inquisitor", allegiance: "Church / Inquisition",
        sigil: "Brown robes", status: "Alive; escorted to back chambers",
        notes: "Seen as a child (~age 9) in Session Knavers time-jump from Sister Erithine's orphanage. 'Just trying not to die.' Testified on behalf of the ecclesiastical church at Decima and Ryo's court session."
      },
      {
        name: "The Marshall", circle: "6th Circle", role: "Military commander; controls Yearning Mines", allegiance: "Vo'dyn / allegedly tied to a noble house",
        sigil: "—", status: "Alive; active",
        notes: "Controls the Special Military Zone (Yearning Mines). Uses colored orb + glass spindle for interrogations. Fiddles with red, yellow, purple marbles. Has Aldred's crest. Appears conflicted — 'his body protests.'"
      },
      {
        name: "Selka Morren", circle: "6th Circle", role: "Lady Factor / Auditor", allegiance: "House Morren / Nobles",
        sigil: "—", status: "Alive; active",
        notes: "Full immunity inside the Yearning Mines. Nobles' only window into mine operations. Accused by Marshall of 'using a heretic.' Kane has been cultivating a relationship with her."
      },
      {
        name: "Zenzar / Xanthran", circle: "6th Circle", role: "Former Militia leader", allegiance: "Zen'tar city (formerly)",
        sigil: "—", status: "Missing ~7 years; being sold to Secus",
        notes: "Disappeared ~same time as the Prince. Nobody could replace him. Found by N'thoda in underground fighting arenas. Being auctioned to Secus by the masked Establishment Leader."
      },
      {
        name: "Mithris", circle: "6th Circle", role: "Consortium founder", allegiance: "Consortium / Self",
        sigil: "Elven sigil (right shoulder)", status: "Dead (~Year 625)",
        notes: "High elf. Ran the Consortium. Passed an oilcloth-wrapped package (almost certainly the green ledger) to Caldun before Arthur's raid. Arthur killed him in single combat at the cost of his own legs."
      },
      {
        name: "Caldun", circle: "6th Circle", role: "Consortium enforcer; possible ledger-holder", allegiance: "Consortium (fractured)",
        sigil: "Mithris's elven sigil", status: "Alive; at large",
        notes: "Elvish name meaning 'weapon.' Trained from childhood as a weapon. Holds the oilcloth package (green ledger?). Broke from fighting Arthur to kill Crane — the Order of the Rose was a high-priority threat."
      },
      {
        name: "Artemis", circle: "6th Circle", role: "Order of the Rose operative", allegiance: "Order of the Rose",
        sigil: "—", status: "Alive; traveling with party",
        notes: "Big, scarred, strong. Crane's apprentice. Has been searching for the oilcloth materials for 8 years. Interested in the green book symbol in the meteorite room. Motto: 'We're not heroes. We're scaffolding.'"
      },
      {
        name: "Volk Stormhammer", circle: "6th Circle", role: "Senior non-penal dwarf miner", allegiance: "Himself / Dwarven tradition",
        sigil: "—", status: "Alive",
        notes: "Old. Non-penal worker in the Yearning Mines. Confirmed dwarven lore: forefathers 'vowed to never speak' of another world. Gets excited around the ancient machines. Seen having tea with the Veinwarden."
      },
      {
        name: "Boltin Crestfyre", circle: "6th Circle", role: "Lt., 4th Investigative Enforcement Wing", allegiance: "Nobles / Magistrate",
        sigil: "—", status: "Alive; active / suspicious",
        notes: "Watched the O'Malley ambush without intervening. Heard the codeword 'Dagger' from the assassins. Now accusing the party of starting the fight. Possible corrupt noble influence."
      },
      {
        name: "Oral Oxthain", circle: "Unknown", role: "Veinwarden", allegiance: "Yearning Mines",
        sigil: "—", status: "Alive",
        notes: "Likely the head of the mine's trustee system (the 'Overman Jar'). Seen having tea with Volk Stormhammer after party was released from interrogation."
      },
    ],
    historical: [
      {
        name: 'Ser Gavriel Val\'Tan ("Him")', era: "Pre-Capital / ~Year 0",
        role: "1st Martyr (theorized)", sigil: "Plinth at The Spur",
        notes: "Sacrificed himself at Basalt Ridge so Vo'dyn could survive the Cataclysm. Said: 'I see the wound that drinks the names of kings.' Buried beneath The Spur. Penal Outriders trace their oath to him."
      },
      {
        name: "The Evening Star", era: "~Year 1-25",
        role: "2nd Martyr", sigil: "—",
        notes: "Led the survivors underground. 'Stood between them and the truth.' Founded the Inquisition through blood and prayer. Possibly also the Warden of the Deep (player theory)."
      },
      {
        name: "Great Martyred Lady", era: "~Year 452",
        role: "4th Martyr", sigil: "—",
        notes: "Died on Martyr's Day. Used magic at great cost. During her era the Great Schism occurred — when the Church asserted dominance over the nobles; one Great House was expunged. Possibly founded the Luminary Council."
      },
      {
        name: "Jorell", era: "~Year 2-24 (journals)",
        role: "5th Martyr", sigil: "Crimson red eyes",
        notes: "Established Avar's capital at 'the thinnest point.' Spent 19 years binding himself to eternal watching of the seal beneath. Struck his name from all records."
      },
      {
        name: "The Quiet Architect (K)", era: "Ancient / Ongoing",
        role: "Ancient interventionist", sigil: "Hourglass; Staff of the Magi",
        notes: "Has gone by many names across history. Carries an hourglass. Has intervened before, in other places, in other times. Warned by The Witness: 'observation, not orchestration.' Theorized to be the Prophet / Final Chronicler."
      },
      {
        name: "The Prophet (Wanderer)", era: "Unknown / Transplanar",
        role: "Ancient seer; gave party the ledger", sigil: "Deep midnight blue cloak, glowing stars; Staff of the Magi",
        notes: "Appeared in Velderra (one-shot). Gave the party the green ledger. No record of ascension. Theorized to be the Quiet Architect (K) and the Final Chronicler."
      },
      {
        name: "Warden of the Deep", era: "Pre-civilizational / Sub-6th",
        role: "Ancient guardian of the Shard", sigil: "Wears a mask; large humanoid; emerged from pool in The Abyss",
        notes: "'I am the hinge that keeps the broken heavens closed.' 'Duty bound to He who stood for us.' Sees corruption in all party members: 'You are all potential vessels.' Has cast off the chains of whatever bound him."
      },
    ],
    entities: [
      {
        name: "Ryo's Wyrm", nature: "Pre-civilizational ancient entity; resides inside Ryo via a severed finger",
        status: "Active",
        notes: "Crimson red eyes. Stronghold in his mindscape: trident, white/red, and lapis lazuli banners. 'Finally, after millenia, I have found a suitable one.' Claims to have saved Ryo from concentrated power. 'I do not serve, I rule.'"
      },
      {
        name: "Fate (entity)", nature: "Primordial force; featureless figure with stars for eyes",
        status: "Dead? ('I knew Fate once. She was killed.')",
        notes: "Encountered by the party in Session Knavers. The green ledger appeared first, dissolved, replaced by Fate. Party asked 'Why is fate so cruel?' — entity replied 'I am fate, aren't I?' The Quiet Architect appears to have loved Fate."
      },
      {
        name: "The Dav Ki", nature: "Pre-human civilization; ancient builders",
        status: "Ancient / ruins remain",
        notes: "Built strongholds to contain deep nightmares. Their volatile ore technology is the 'secret of Dav Ki.' The Yearning Mines are built on their ruins."
      },
      {
        name: "The Urd", nature: "Cosmic parasite / hunger",
        status: "Resurfacing (Dwarven Report, Year 622)",
        notes: "'Not spiders, not exactly — more like a hunger that learned to build webs.' Brought from another world by Dark Elves. A symptom, not the cause, of the Cataclysm. May be parasitic forces living inside cognition and memory."
      },
    ]
  },

  // Player characters
  players: [
    {
      name: "Mithe Demacia Khol", echo: "BLOOD", race: "Half-Elf", cls: "Bard", age: "19", height: "5'6\"",
      origin: "1st Circle (raised Capital / Da'varre); now 6th Circle",
      appearance: "Left eye whites permanently blackened from a failed arcane alteration.",
      bio: "Bastard daughter of Midas Khol and elven mage Lux. Raised as a ward of House Da'varre under Count Alren. Imprisoned at 19 after an assassination attempt on Midas following Lux's death from entropic decay. Educated in nobility, politics, and healing. Father is Midas (alive; known only to Midas). Legal guardian is Alren Da'varre.",
      connections: "Father: Midas Khol (secret). Guardian: Count Alren Da'varre. Mother: Lux (high elf mage, deceased).",
      echoBg: "#8b1a1a"
    },
    {
      name: "Ryo Dayana", echo: "KEY", race: "Human", cls: "Sorcerer", age: "21", height: "5'9\"",
      origin: "8th Circle origin (Bandlewoods farm); now 6th Circle",
      appearance: "Slight red marks in mostly black hair; faint black markings on face.",
      bio: "Former farmer and self-professed historian. Found an ancient entity's severed finger in a chimera's mouth — absorbing it awakened him as a sorcerer. The Wyrm inside him needs a 'suitable host.' Carries an obsidian key-spline (3 triangle notches) and a partial mural rubbing. Being chased by a branch of the Inquisition.",
      connections: "Hunted by branch of the Inquisition. Obsidian key-spline (3 triangle notches). Partial mural rubbing: 'Weaver's Arch,' 'IV:3,' 'Westwell 2nd,' trident sigil.",
      echoBg: "#2a4a7f"
    },
    {
      name: "Decima Domitae", echo: "VEIL", race: "Human", cls: "Sorcerer", age: "Early 20s", height: "5'2\"",
      origin: "3rd Circle (Domitae); now 6th Circle — uses alias Delattre",
      appearance: "Eyes originally green, now unnaturally pale — blind.",
      bio: "10th child of House Domitae. Lost her sight and speech upon waking with an entity from another plane eating her memories. Made a deal she doesn't remember. Became a heretic after beloved sister Nona disappeared into the clergy. Researched 'changing Fate.' Read the Wyrm's apprentice's tome. Branded by brother Secus. Holds herself regally.",
      connections: "Brother: Secus Domitae (House Khol). Sister Nona (possibly killed by Velintra). Father: Magus. Mother: Julia.",
      echoBg: "#4a2a7f"
    },
    {
      name: "Velintra Caelmyr", echo: "MASK", race: "Dark Elf / Owlin", cls: "Rogue", age: "27 (human years)", height: "5'8\"",
      origin: "Outside standard circle structure",
      appearance: "Crimson red eyes. Long snow-white hair in braids with garnet and silver pendants.",
      bio: "Member of a dark elf guild that tortures and kills. Confident, well-poised, strong moral code in specific areas. Possibly responsible for the death of Nona Domitae (Decima's sister). Connected to the high-elf/dark-elf war era. Knocked Ryo and Decima unconscious during the Wyrm encounter.",
      connections: "Dark elf guild (unknown name). Resembles Sister Erithine. Recognized someone in the burning-village time-vision.",
      echoBg: "#2a4a2a"
    },
    {
      name: "Kane Vestrist Forscin", echo: "ECHO", race: "High Elf", cls: "Warlock", age: "100+", height: "—",
      origin: "Circle of origin unspecified",
      appearance: "High elf; ancient bearing.",
      bio: "Haunted by a shadowy entity — most likely his dead twin brother Able, puppeted by a vampire necromancer. Made a deal with an apparation upon witnessing his brother's death during the high-elf/dark-elf war. Doesn't trust dark elves. Has been cultivating a relationship with Selka Morren.",
      connections: "Twin brother Able (deceased, ~100 yrs ago during high elf/dark elf war). Made deal with an Apparation.",
      echoBg: "#4a3a1a"
    },
    {
      name: "Aldred", echo: "OATH", race: "Human", cls: "Paladin", age: "—", height: "—",
      origin: "Former Order of the Flame; circle unspecified",
      appearance: "Large; heavy silver armor.",
      bio: "Former paladin of the Order of the Flame, now likely possessed by a demon — does not appear to realize this. The only survivor of the pentagram incident, woke with sword bloodied and amulet glowing red. Doesn't remember why he was banished from the Order. Receives powers from God. The Marshall has his crest.",
      connections: "Former Order of the Flame. Marshall has his crest. Order possessed 4 oathblades.",
      echoBg: "#1a3a4a"
    },
    {
      name: "N'thoda", echo: "FLAME", race: "Human", cls: "Barbarian", age: "21", height: "6'2\"",
      origin: "6th Circle (Zen'tar underground arenas)",
      appearance: "Black hair; bruises and scars from underground fighting arenas.",
      bio: "Observant; fight-first mentality. Trying to learn more about the world. Was fighting Zenzar in the ring when the party found the former militia leader. Escaped the O'Malley scene through the sewers.",
      connections: "Found Zenzar in underground fighting arenas.",
      echoBg: "#7f2a0a"
    },
    {
      name: "Thog Mossass", echo: "ROOT", race: "Firbolg", cls: "Druid", age: "—", height: "—",
      origin: "Outer / Frontier (beyond circle classification) — aliases: Corvus, 'The Devil of 19B,' 'Saint of Spores'",
      appearance: "Patchwork of bark, twine, feathers, and moss. Face obscured by archaic plague helm. Carries a gnarled bough.",
      bio: "Classified by the Empire as a 'Pagan druid / Suspected eco-terrorist.' Frontier populations revere him as a 'virulent guardian.' Opened a diplomatic channel with Caldun. Currently sitting at the Drunken Dog Inn during the O'Malley crisis.",
      connections: "Diplomatic channel with Caldun. Empire classification: eco-terrorist.",
      echoBg: "#1a4a1a"
    },
  ],

  // Locations grouped by region
  locations: {
    zentar: [
      { name: "The Yearning Mines", zone: "Southwest; red-bordered zone", controller: "The Marshall (Special Military Zone)", notes: "Main export: Cobalt (blue and explosive when awakened). Penal colony. Pits of Hell spiral deep. Every 7th thump + silence on 4th-of-4th = warning signal. Meteorite chamber below with star map. 4 ancient entropic stabilizer machines." },
      { name: "The Abyss (sub-mine)", zone: "Sub-6th; deepest mine level", controller: "Warden of the Deep", notes: "'A room that hears itself. A single drop meets the lake and the ripples never finish.' Large pool. Fog curls. Cobalt absorbs magic. The Warden emerged here." },
      { name: "Meteorite Chamber", zone: "Sub-mine (past the ebony gate)", controller: "Unknown / Ancient", notes: "Natural meteorite — unheard of. Cylindric table with concave top. Star map on ceiling matching Mithe's pool visions. Three wall symbols: Green Book, Blue Scepter, Red Crown. Five masks in side hallway." },
      { name: "Merchant District", zone: "Central/North; white-bordered zone", controller: "Merchant Guilds / Hired mercenaries (contested)", notes: "Site of O'Malley's ambush and killing. Merchants kicking out magistrate; bringing their own mercenaries. Trebuchets, arbalests, and scorpions being assembled. Maestor Velitor disappeared." },
      { name: "Drunken Dog Inn", zone: "Intermediary District", controller: "Neutral", notes: "Party base. Lantis frequented here. Drinking competitions, poker, floor-level espionage. Thog is currently here during the Session 17 crisis." },
      { name: "Sunken Croc (Tavern)", zone: "Outskirts / Lower district", controller: "Consortium / Blue Pirates", notes: "Front for criminal operations. Drinking competition (Ryo), Decima's money loss, upstairs conspiracies. Secus met here with the masked Establishment Leader." },
      { name: "The Warf (Dockyards)", zone: "South / waterfront", controller: "Militarum / 7th Fleet (now)", notes: "7th Fleet docked here. Naval yellow flares fired from these waters. Arthur conducted his raid on Blue Pirates here years ago." },
      { name: "Ravenward Keep", zone: "East", controller: "'The Wardens' / Zentari 1st Regiment", notes: "Major fortification. 7th Fleet flagship anchors nearby." },
      { name: "Magistrate / City Guard Station", zone: "Upper District", controller: "City Guard / Nobles", notes: "Blood at the fortified door during Session 6. Arthur was inside with sword-cane drawn. 3-4 guards downed. Investigator Station is here." },
      { name: "AX42 Sanitarium", zone: "Outskirts", controller: "Unknown", notes: "Last known location of the disappearances. Syndicate Agents nearby on map." },
      { name: "The Spur", zone: "Southern wall of Zen'tar", controller: "Unguarded (sacred)", notes: "Bare stone plinth. Ser Gavriel Val'Tan buried beneath. Penal Outriders recite their oath here. 'The wound beneath the Spur has never truly slept.'" },
      { name: "Weaver's Arch", zone: "Zen'tar proper (ruined)", controller: "Ruined", notes: "Where the late Duke gave speeches before his death. Now broken stones and rock. Referenced in Ryo's partial mural rubbing." },
    ],
    empire: [
      { name: "Kholinar ('The Capital')", circle: "1st Circle", controller: "High Nobility; Vo'dyn Empire", notes: "Center of the empire. Jorell built the capital here at 'the thinnest point' so living civilization would press against the seal." },
      { name: "Gloamspire", circle: "1st Circle (Capital outskirts)", controller: "House Da'varre", notes: "Tower rising from a still cavern lake. Halls lit by glass lanterns and etched mirrors that glow when truth is spoken. Da'varre's archive and ancestral seat." },
      { name: "Basalt Ridge", circle: "6th Circle (Zen'tar Stronghold foundation)", controller: "Historical / Stronghold foundation", notes: "Where Gavriel's company held for 10 hours during the Cataclysm retreat. Ridge 'trembles on windless nights.' 'The wound beneath the Spur has never truly slept.'" },
      { name: "Principality of Al'tan", circle: "Outside Zen'tar / Independent", controller: "Mixed / Self-governing", notes: "One of only two mixed-race locations empire-wide. Small community of a few strongholds. Used as neutral meeting ground." },
      { name: "The Bazaar", circle: "6th Circle / Inquisition-controlled", controller: "Inquisition (direct governance)", notes: "The second of only two mixed-race locations in the empire. One of the few places directly governed by the Inquisition rather than a noble house." },
      { name: "Banmore Keep", circle: "10th Circle", controller: "Highlord Xzal", notes: "Edge of Avar. Xzal sealed a redacted report (Year 606 / 616) about unknown others beyond the borders who rebuffed contact and consumed every expedition." },
      { name: "Velderra", circle: "Surface world (pre-cataclysm)", controller: "Destroyed", notes: "Surface territory lost to the Cataclysm. Two moons (silver/gold), blue-white sun, red pulsing planet. Location of the one-shot. The Prophet gave the party the green ledger here." },
    ]
  },

  // Sigils and visual markers
  sigils: {
    confirmed: [
      { sigil: "Red Fist", assoc: "Duke of Zen'tar / House Mournen", circle: "1st / 6th Circle", seen: "Confirmed Session 5 (Lantis at Sunken Croc)", meaning: "Sigil of the late Duke. Used to identify loyalists and materials connected to Mournen's dynastic rule of Zen'tar." },
      { sigil: "Blue Hand Glove with Crest", assoc: "Hathor / Order of the Blue Fist", circle: "1st Circle", seen: "Session 2 — on Hathor", meaning: "Identifies Blue Fist members. Cadet branch of House Mournen. Military, not religious." },
      { sigil: "Elven Symbol (right shoulder)", assoc: "Mithris / Consortium; also House Maelis", circle: "6th Circle", seen: "Session 4 (cloaked figure); Session 5 (Caldun)", meaning: "Mithris's personal elven sigil. High-elf identifier. May overlap with Maelis." },
      { sigil: "Gray Banner / Crimson Red Drops", assoc: "Penal Outriders / Penitant Deathriders", circle: "6th Circle+", seen: "Referenced in lore; seen at Duke's funeral", meaning: "Bone-white helmets with rank scraped off. Oath taken at The Spur before missions." },
      { sigil: "Brown Robes + Rosette", assoc: "Inquisition", circle: "Empire-wide", seen: "Session 2 (road); Session Knavers", meaning: "Standard Inquisition field uniform. New rosettes have magic-key properties; older ones were engraved power symbols." },
      { sigil: "Sigil of Him (on ships)", assoc: "7th Fleet / Vo'dyn Empire religion", circle: "6th Circle (docked)", seen: "Session 14 — on every 7th Fleet ship", meaning: "Holy/imperial identifier of the highest order. Signals both religious and imperial authority." },
      { sigil: "Rose-Sealed Wax Orders", assoc: "Order of the Rose", circle: "Unknown / Covert", seen: "Referenced by Crane/Artemis", meaning: "Written mission orders sealed with a rose wax emblem. Only identifier of the secretive order." },
      { sigil: "Hourglass (pendant / staff)", assoc: "The Quiet Architect (K) / Midas Khol / The Prophet", circle: "Transplanar / 1st Circle", seen: "Session 16 (Midas to Valerian); Session Knavers (Ashen Warrior)", meaning: "Symbol of the Quiet Architect. Midas gave one to Valerian: 'I'll keep the hourglass turning.'" },
      { sigil: "Thorn Talisman", assoc: "O'Malley / Unknown faction", circle: "6th Circle", seen: "Session 16 — found on O'Malley's body", meaning: "Affiliation unknown. O'Malley's possession suggests possible allegiance beyond the merchant guild." },
      { sigil: "Four-Leaf Clover", assoc: "House Khol", circle: "1st Circle", seen: "House heraldry", meaning: "House Khol's identifying sigil. Symbol of prosperity and fortune." },
      { sigil: "Glass Prism", assoc: "House Da'varre", circle: "1st Circle", seen: "House heraldry; Gloamspire architecture", meaning: "Truth-telling association. The mirrors of Gloamspire glow when truth is spoken." },
    ],
    meteorite: [
      { marker: "Green Book", location: "Meteorite chamber wall (1st symbol)", meaning: "Luminescent. Feelings: regality, inevitability, loss. Label: 'Fate's Final Rest.'" },
      { marker: "Blue Scepter", location: "Meteorite chamber wall (2nd symbol)", meaning: "Label: 'Humanity's Unyielding Spirit.'" },
      { marker: "Red Crown", location: "Meteorite chamber wall (3rd symbol)", meaning: "Sadness, melancholy, anger, betrayal; also happiness, certainty, faith. Labels: 'The end of the Starborn.' / 'My sacrifice is your duty.' Mithe took -3 psychic damage touching it." },
      { marker: "Obsidian Mask (1st)", location: "Side hallway off meteorite chamber", meaning: "Ryo's key activates it: 'Before the first veil was woven, the universe was our anchor — and I was its guide.'" },
      { marker: "3rd Mask Reed", location: "Side hallway", meaning: "Comes out freely; thin charcoal line reads 'For the many masks you've worn throughout time.'" },
      { marker: "5th Mask Reed (key-shaped)", location: "Side hallway", meaning: "'For the life you left behind.' — used to unlock the exit door." },
    ],
    armbands: [
      { color: "Red armbands", location: "Magistrate attack (Session 6)", affil: "Attackers — suspected Brigans or Blue Pirates" },
      { color: "Green armbands", location: "Yearning Mines entrance (Cavers)", affil: "Lower mine guard rank" },
      { color: "Maroon armbands", location: "Yearning Mines (Cavers)", affil: "Mid-rank mine guards" },
      { color: "Darker armbands", location: "Yearning Mines (guards around Mithe/Ryo)", affil: "Higher authority; senior mine staff" },
      { color: "Silver armbands", location: "Interrogation (Session 12)", affil: "Guards who took Thog to be 'killed'" },
      { color: "Black armbands", location: "Interrogation (Session 12)", affil: "Marshall's personal guard; Rarik Ville's escorts" },
      { color: "Blue feather", location: "Merchant District checkpoint (Session 16)", affil: "Militarum guards at district boundary" },
    ]
  },

  // World lore and cosmology
  lore: [
    { concept: "The Wound", nature: "Ancient corruption beneath consciousness; pre-cosmic", connection: "= Abyss = Urd = Everfrost = Quiet/Silence = Mouths = Fog = Forgetfulness = Stain. DM confirmed equivalence.", status: "Sealed beneath Avar's capital. Seal straining as the hymn grows thin. Every 7th thump + 4th-of-4th silence signals its stirring." },
    { concept: "The Three Fundamentals + Entropy", nature: "Matter (resists), Energy (moves), Flux (changes). Fourth: Entropy.", connection: "Confirmed in machine panels in the Yearning Mines. Awakened Cobalt is the only thing that counters the Flux.", status: "'Entropy can only be delayed.' The four ancient machines in the mines enforce this delay via a 16-beat rhythm." },
    { concept: "The Veils", nature: "Metaphysical barriers woven over the Wound", connection: "Each likely created through a Martyr's sacrifice. The 16-beat machine rhythm preserves the veil via 'humanity's hymn.'", status: "Currently thinning. 'When it thinned and forgetting learned to sing, I was no maker, only a keeper.'" },
    { concept: "The Shard", nature: "Fragment of the Wound / broken heavens", connection: "The Warden keeps it sealed under the Yearning Mines. 'I keep the shard beneath the surface of our night.' Party are all 'potential vessels.'", status: "Contained. The Warden's jar metaphor: earth = walls, fog = fluid, cities settled like silt atop it." },
    { concept: "The Martyrs", nature: "Willing sacrifices who weave veils and become eternal watchers", connection: "1st = Gavriel; 2nd = Evening Star; 3rd = Unknown; 4th = Great Martyred Lady; 5th = Jorell; 6th-7th = Unknown.", status: "Possibly continue to exist as watchers on the Threaded Paths. United with The Witness's coalition against the Wound across spheres." },
    { concept: "The Primordials", nature: "Personified cosmic concepts (Oath/Law, Exile, Fate, Truth, Honor)", connection: "Appear in 'Echoes of the Veil.' Law wrote a Final Litany. Fate has been killed ('I knew Fate once. She was killed.').", status: "Oath/Law is the entity in crystal reliquary (SD-DeltaXi-HN). Exile exists 'beyond the margin.'" },
  ],

  // Key active plot threads
  threads: [
    { title: "The Ledger Trail", status: "UNKNOWN — Last confirmed: Caldun (oilcloth package)", detail: "Prophet gave it in Velderra to heroes who carried it to the Duke of Zen'tar — Duke killed for/by it — Mithris obtained it — passed to Caldun in oilcloth before Arthur's raid — explosion at warehouse — status unknown. The ledger is described as 'as primordial as the magic in the air.'" },
    { title: "The Coup Network", status: "Actors: Secus Domitae + masked Hathor + Blue Pirates + Militia (via Zenzar)", detail: "Secus (1st Circle via Khol marriage) is purchasing Zenzar (former militia leader) through a masked figure (likely Hathor) to intend a coup of the Council of Regency. Guild affairs: 'next hit prince loyalists and Arthur.' Multiple factions converging on the post-Duke power vacuum." },
    { title: "Midas's Long Game", status: "Operator: Midas Khol — Agents: Valerian Than'dal", detail: "Midas (old friends with the Duke) knew the Duke found something. Sent Valerian to watch the Prince. At the funeral: 'I'll keep the hourglass turning.' Possibly also behind the Order of the Rose (Crane/Artemis). Timeline accelerated by the Duke's death." },
    { title: "The Party's Possession Problem", status: "Affected: Ryo (Wyrm), Decima (unknown entity), Aldred (demon), Kane (vampired twin)", detail: "All four are haunted/possessed. The Wyrm inside Ryo apprenticed a Domitae — connecting it to Decima's family. All are 'potential vessels' per the Warden. Decima doesn't think Aldred realizes he is possessed." },
    { title: "The 7th Fleet's Arrival", status: "Commander: Admiral Galewind — Ship: The Martyr (flagship)", detail: "Unexpected. Pre-cataclysm ship. Nobody knows why they're here — including the Marshall's own spy. Carries 'Sigil of Him' on each vessel. Under Nautica Liticus. Triggered martial law upon arrival." },
    { title: "The Disappearances", status: "Pattern locations: Sanitarium — Yearning Mines — Merchant District — broader city", detail: "Missing: Ralph Alvarez (mines), Jonathan Wineford (mines), Lantis (investigator), Maestor Velitor (Guild Master), the Prince. Mine manifest discrepancy: 16 in ledger, 15 went down, 14 came back. Pattern mirrors Velderra: those who 'reach too far' are taken." },
  ],

  // Known timeline
  timeline: [
    { era: "Pre-cataclysm", event: "Velderra civilization flourishes on the surface. Two moons (silver/gold), blue-white sun, red pulsing planet. Magic flows freely. Dav Ki civilization flourishes underground. High-elf/dark-elf war. House Voss visible in proto-elvish Fragment 8C — involved in inter-dimensional activities." },
    { era: "~Year 0 (Cataclysm)", event: "The sky breaks. Scholars of Velderra 'reached through the veil' and the Urd came through. Reality frayed. Ser Gavriel Val'Tan ('Him') sacrificed himself at Basalt Ridge — held 10 hours with his company on the final day. The 7th Fleet descended. The Vo'dyn devout fled underground, seizing the ruins of the Dav Ki." },
    { era: "~Year 1-25", event: "The Evening Star (2nd Martyr) led survivors underground. Stood between them and the truth. Founded the Inquisition through blood and prayer. The surviving Great Houses formed." },
    { era: "~Year 2-24", event: "Jorell (5th Martyr) established Avar's capital at 'the thinnest point.' Over 19 years, his gift of sight bound him to eternal watching of the seal beneath. Struck his name from all records." },
    { era: "~Year 427", event: "The Recreance: magically-attuned races became more mundane. Pre-cataclysm magic suppressed." },
    { era: "~Year 452 (est.)", event: "The Great Martyred Lady fell on Martyr's Day. Used her magical curse for Vo'dyn. During her era: the Great Schism occurred — the Church asserted dominance over the nobles; one Great House was expunged." },
    { era: "Year 512", event: "The Grand Scholar wrote: 'Life is not a riddle to be solved.' Later annotated (~Year 524): 'greatest lie.'" },
    { era: "Year 606", event: "Highlord Xzal sealed a redacted report: others beyond the borders rebuffed all contact; every expedition disappeared." },
    { era: "Year 616", event: "Aeilin (High Elves) disappearance documented in the redacted report." },
    { era: "Year 618", event: "Duke of Zen'tar died (officially: heart failure; widely disbelieved). Beginning of the current crisis. Prince disappeared around this time or earlier." },
    { era: "Year 622", event: "Dwarven Report: Urd resurface. Dark Elf lords wandering borders with malevolent intent." },
    { era: "~Year 625", event: "Arthur Augustus killed Mithris. Blue Pirates fractured. Caldun killed Crane (Order of the Rose). Artemis survived." },
    { era: "Year 626 (CURRENT)", event: "The Awakening — ancient magics reawakening. 7th Fleet arrives unexpectedly at Zen'tar. Martial law declared. The party enters play. O'Malley killed by Consortium. New Year is 270 cycles away." },
  ],

  // Theories — DM confirmed vs player theories
  theories: [
    { label: "270 Cycles to New Year Is Not a Random Number", confirmed: true, detail: "DM confirmed: '270 cycles. No, this is not a random number.' Magic re-emerged at year 427 (The Recreance), then again in year 626 (The Awakening) — exactly 199 years later." },
    { label: "Awakened Cobalt Is the Only Counter to the Flux / Wound", confirmed: true, detail: "DM confirmed: 'Awakened Cobalt is the only thing to counter the flux.' The Cobalt in the mines ripped open a portal between realities, suggesting it interacts with the seals holding the Wound at bay." },
    { label: "First Circler = Secus", confirmed: false, detail: "The 'First Circler' Garth desperately wants to impress is theorized to be Secus — Decima's brother — who married into House Khol, a 1st circle family." },
    { label: "Hathor = The Establishment Leader", confirmed: false, detail: "Hathor (Military Adjutant, 3rd circle, House Bluefist/Mournen, blue glove) is theorized to be the masked Establishment Leader from the Sunken Croc meeting." },
    { label: "Lantis = Mithris's Child", confirmed: false, detail: "Arthur massacred the Blue Pirates and killed their half-elf leader Mithris, yet now associates with Lantis — another half-elf. Theory: Mithris had a child; Arthur spared him out of guilt." },
    { label: "The Duke Found the Ledger and Was Killed for It", confirmed: false, detail: "'In the deepest vault I found a ledger... I feel them already, nibbling at my name.' The late Duke likely found the ancient ledger and was targeted for it." },
    { label: "The Martyrs Become the Veil / Watchers", confirmed: false, detail: "Each veil of the world was created from the sacrifice of a Martyr. Current working list: 1st = Gavriel/Him, 2nd = Evening Star/Warden?, 4th = Great Martyred Lady, 5th = Jorell." },
    { label: "The Quiet Architect (K) = The Prophet = The Final Chronicler", confirmed: false, detail: "All three carry or are associated with hourglasses and probability control. The Ashen Warrior in the Knavers portal vision wore a hourglass pendant — possibly K observing the Velderra-era events." },
    { label: "Vo'dyn Religion Suppresses Knowledge of the Wound", confirmed: false, detail: "Heresy = curiosity and deviation from doctrine. The Cataclysm was caused by overreach which woke the Urd. The Church rewrote it as divine punishment to stop people trying to understand the Wound." },
    { label: "The Coup Web: Marshall / Blue Pirates / Secus / Hathor", confirmed: false, detail: "The Marshall is in talks with Lantis (Blue Pirates adjacent). The Blue Pirates connect to Secus and the masked Establishment Leader (theorized = Hathor). Secus (House Khol) is organizing a coup." },
    { label: "Evening Star = Warden of the Deep", confirmed: false, detail: "The Evening Star (2nd Martyr) who 'stood between them and the truth' may also be the Warden of the Deep — duty-bound since the earliest days of Avar, now cast off those chains." },
    { label: "Midas Khol Controls Probability / Is Behind the Order of the Rose", confirmed: false, detail: "'I'll keep the hourglass turning' — giving Valerian the pendant at the Duke's funeral may be a signal, not just a gift. Midas may also be behind the Order of the Rose (Crane/Artemis)." },
  ],

  // Session notes
  sessions: [
    {
      id: "s0", title: "Session 0 — The Caravan Begins",
      events: ["A lizard pulls the caravan. Party is in chains."],
      intel: [],
      dm: "Campaign Theme: 'You are all in a remnant of a decaying empire continuously losing its border skirmishes. And the only faith that exists is religious fervor. And the fact magic / tech is starting to innovate again.'"
    },
    {
      id: "s1", title: "Session 1 — Goblin Ambush on the Road",
      events: ["Party fought goblins and an ogre on the caravan road.", "Obtained an echo for a devil's bargain of small consequence. +1 insight (about enemies).", "A devil's laugh is heard at the end of the session."],
      intel: ["Blue Fist markings visible on boards along the road — noted as 'slightly out of place as they are from the 3rd circle.'", "Scouts reported the ambush ahead of time, suggesting someone knows the party's route.", "The dead ogre and goblin leader had an unusual arcane aura — not normal for this creature type.", "Verin Ralthar introduced as head supervisor — adverse to magic; his name is on the contract signed with blood."],
      dm: ""
    },
    {
      id: "s2", title: "Session 2 — En Route to Zen'tar; Mist Wraiths",
      events: ["Introduction to Vo'dyn prayer and religious tenets: cleanliness, faithfulness, service to 'Him.'", "Party received battered symbols — oak talismans with inlaid steel.", "Hathor (Military Adjudicant) encountered on the road: 'We know and saw the enemy, ash and dust.' Wears a blue hand glove with crest.", "A woman, Evelynn, screams of her missing child. Party encounters mist wraiths — weak to radiant damage (1d10 per turn). 'They will return to the earth, forgotten.'"],
      intel: ["Mist wraiths returning 'to the earth, forgotten' mirrors the language of the Wound and the Urd.", "Criminal organizations mentioned as working inconsistently with guilds."],
      dm: ""
    },
    {
      id: "s3", title: "Session 3 — Arrival in Zen'tar; The Missing Prince",
      events: ["Attempted to speak with Evelynn (the mother from Session 2). Velintra witnessed the mother kill herself.", "Overheard: 'The prince will be secured. Is the plan in motion? Yes. We must secure the paradigm. The diadem will give us the correct portent.'", "Arrived in Zen'tar. Confirmed: Duke dead; Prince missing.", "Party tasked: find Junior Investigator Lantis, who has gone missing while leading the disappearances investigation."],
      intel: ["'The diadem will give us the correct portent' — a diadem is a crown-like object associated with ruling succession.", "'The paradigm' is undefined — possibly the ledger, possibly the Prince himself."],
      dm: ""
    },
    {
      id: "s4", title: "Session 4 — Disappearances; The Sunken Croc",
      events: ["Investigated disappearances. Last known location: AX42 Sanitarium block.", "Spotted a cloaked figure with an elven symbol on the right shoulder (Consortium/Maelis identifier).", "An hourglass stamp seen on an entrance notice — unknown affiliation at this point.", "Party entered the Sunken Croc. Ryo entered a drinking competition. Decima lost all her money and was taken upstairs."],
      intel: ["Hourglass stamp on entrance notice — later connects to the Quiet Architect / Midas / Valerian thread.", "Elven symbol on cloaked figure's right shoulder — Mithris's personal elven identifier."],
      dm: ""
    },
    {
      id: "s5", title: "Session 5 — Blue Pirates Confirmed; Secus; Caldun's Attack",
      events: ["Confirmed: Blue Pirates control this area. Heavy-handed, uncouth. Hate Arthur Augustus specifically.", "Upstairs at the Sunken Croc: Secus in a room with a masked Establishment Leader. Overheard: 'Guild affairs — next hit prince loyalists and Arthur.'", "Secus brands Decima as a test of loyalty to the masked man.", "Outside the tavern: party confronted by Caldun — cloaked, heavily armed, bearing Mithris's elven sigil. He attacks because the party is investigating what 'some people would prefer remain untouched.'", "Establishment Leader trying to sell Zenzar (ex-militia leader) to Secus."],
      intel: ["Red fist = confirmed sigil of the late Duke (Mournen).", "Secus (married into 1st Circle via Khol) is buying Zenzar through a masked figure (likely Hathor, Order of Blue Fist)."],
      dm: ""
    },
    {
      id: "s6", title: "Session 6 — Magistrate Attack; Entering the Mines",
      events: ["Devil's bargain occurred. Lantis remains missing — possibly dead.", "Party reaches the Magistrate office: blood at the fortified door. Arthur found inside with cane/sword drawn. 3-4 guards downed. Attackers had red armbands.", "Party tasked: find the missing people before 'the Bigwigs' arrive at the city.", "Velintra finds a Dark Elf dead on the road with a unique weapon. It is snowing.", "Rest of party moves toward the Yearning Mines."],
      intel: ["Coordinated attacks across the entire Ministerial and Aristocracy District simultaneously.", "Red armbands on attackers — suspected Blue Pirates or Brigans."],
      dm: ""
    },
    {
      id: "scavers", title: "Session Cavers (Parts 1-3) — The Yearning Mines & The Abyss",
      events: ["Manifest Board discrepancy: 15 went down, 14 came up. The ledger showed 16. Ralph Alvarez is missing.", "Every 7th thump: a pause + brief light flicker. The 4-beat machine rhythm begins here.", "Party falls through mine floors. Survivors: Artemis, Volk Stormhammer, Ryo, Mithe, Thog.", "Party discovers the dark ebony gate: hitting the chain on-beat unlocks the gate without penalty. Off-beat = psychic damage.", "The Warden of the Deep emerges from the pool. 'I am the hinge that keeps the broken heavens closed... You are all potential vessels.'", "Through a 7 ft seam: a circular room of natural meteorite — unheard of.", "Ceiling: star map of yellow dots matching Mithe's pool visions.", "Three wall symbols touched by Mithe: Green Book ('Fate's Final Rest'), Blue Scepter ('Humanity's Unyielding Spirit'), Red Crown ('The end of the Starborn' / 'My sacrifice is your duty'). Mithe takes -3 psychic damage on Red Crown.", "Five masks in side hallway. 1st (Obsidian): 'Before the first veil was woven, the universe was our anchor — and I was its guide.' 5th Reed unlocks exit door: 'For the life you left behind.'", "Beyond the door: 4 ancient machines. Three thumping; 4th struggling. 'Entropic stabilization containment failing.'", "Machine panels: Matter / Flux / Energy / Entropy. Party fixes the 16th beat."],
      intel: ["Volk on another world: 'The forefathers vowed to never speak of this topic.'", "Prestidigitation fails when it too closely replicates the star map pattern: 'almost as if it is a system of rule or law that cannot be broken.'"],
      dm: ""
    },
    {
      id: "sknavers", title: "Session Knavers — Rarik Ville; The Cobalt Portal; Fate",
      events: ["A tall brown-robed man (Inquisitor) mistakes Velintra for 'Sister Erithine.' Rarik Ville seen as a child (~age 9) in a time-jump: he is from Sister Erithine's orphanage.", "Selka Morren introduced as 'Lady Factor.'", "Decima strikes the magical item (awakened cobalt). The box begins to break. The awakened cobalt rips a portal between realities.", "Party spawns in a burning village. 'Ashen Warrior': high-quality gear, epaulettes scrubbed off, covered in ash, hourglass glass pendant.", "The Fate Encounter: The green-bound ledger appeared before the party. Replaced by a featureless figure with stars for eyes. 'Why is fate so cruel?' — 'I am fate, aren't I?'"],
      intel: ["Hourglass pendant on the 'Ashen Warrior' connects to Midas's gift to Valerian and the Quiet Architect.", "Symbol of Avar — seen on the ornate glowing box that triggered the cobalt portal event.", "Velintra recognizes the Ashen Warrior from somewhere."],
      dm: ""
    },
    {
      id: "s11", title: "Session 11 — Marshall's Interrogation (Part 1)",
      events: ["The Marshall uses an orb + glass spindle for interrogation: taps when hiding something, blue = truthful, purple = hiding something.", "The Marshall reveals: The Council of Regency had something to do with the Duke's death.", "Original 12 Great Houses explained: 9 known, 1 lost to time, 2 expunged. One expelled during the Great Schism."],
      intel: ["Special Military Zone = Marshall's jurisdiction. Only the Auditors and the head of the city can contest it. No head of city currently exists."],
      dm: "DM confirmed: The Council of Regency had something to do with the Duke's death."
    },
    {
      id: "s12", title: "Session 12 — Marshall's Interrogation (Part 2)",
      events: ["Full interrogation sequence. All have wristbands.", "Thog sent to be executed — guards have silver armbands — escaped as a spider.", "Aldred: Marshall has his crest.", "Marshall accuses Decima of being a 'witch.' Claims: 'The tragic incident was from a heretic employed by Lady Morren.'", "Outside the interrogation room, the Marshall's body 'looks as if it is protesting against what he is doing. He is not happy.'"],
      intel: ["Silver armbands = guards who took Thog. Black armbands = Marshall's personal detail.", "The Marshall blaming Selka Morren may be a strategic deflection."],
      dm: ""
    },
    {
      id: "s13", title: "Session 13 — Release; The Three-Rune Bracelets; Martial Law Buildup",
      events: ["Marshall offers compromise: remote-activatable bracelets. 'If activated, you will no longer be anyone's problem.'", "Party given older, slightly chipped bracelets — runes facing inward (touching skin).", "Three runes: 1st = 'Strictus.' 2nd = airy/free-flowing feel ('Aerie?'). 3rd = familiar but unidentified.", "Town crier announces martial law. Faction alignment clarified: Garth/Magistrate — Nobles. Marshall — refuses noble access to mines. Inquisitor Rarik Ville — 'just trying not to die from Marshall.'"],
      intel: ["Runes are 'like transistors' — reactive, not active. The 3rd rune being 'familiar' suggests the party has encountered a version before.", "Marshall fiddles with red, yellow, and purple marbles — purpose unknown."],
      dm: "DM: 'Runes are reactive, not active... Think of them as transistors.'"
    },
    {
      id: "s14", title: "Session 14 — The 7th Fleet Arrives; Merchant District Tensions",
      events: ["Yellow naval flares seen from the waters. N'thoda appears.", "A trail of ships enters and begins surrounding the city. Ships carry Vo'dyn empire flags. Sigil of Him on each ship.", "City guard declares martial law on outer walls. Garth: 'Nobody was expecting these ships, those are naval flares.'", "7th Fleet briefing: Led by Admiral Galewind; deputy Commodore Sal'vin (Hell's Fury). Under Nautica Liticus. The Martyr is the flagship: pre-cataclysm galleon, 600+ years old.", "Merchants hiring ruffians; assembling trebuchets, arbalests, and scorpions in the Merchant District."],
      intel: ["Nobody was expecting them — not even the Marshall's own spy.", "Yellow = naval flares. Red/green = city flares. Blue feather = Militarum guards at merchant district checkpoint."],
      dm: ""
    },
    {
      id: "s15", title: "Session 15 — The Wyrm Speaks; Ryo & Decima's Shared Vision",
      events: ["Both pulled into a shared space: a wooden-furnished room, grandfather clock in center. 3 candles: 1 red, 1 green, 1 blue. Only green is lit. Clock reads 11:50.", "The Wyrm speaks: 'Without me, you would have been sundered, destroyed, like her. I protected you... The concentrated power of—' [gargle; tries to say a name; cannot say it].", "'This thing has destroyed worlds, empires. Only the foolish are not afraid of those THINGS. I do not serve, I rule.'", "To Decima: 'You've read my apprentice's tome I see. You asked for it. You agreed to get this gift... A price paid. A gift given. A fate rewrote. I chose my own fate. You? You've given it away.'", "Ryo's Dirty 20 Perception: The Wyrm's eyes are crimson red. Stronghold visible with banners: Trident, White banner with a red dot, Lapis lazuli color banner.", "Green candle's wick shortens; flame begins on the red candle. Clock strikes midnight. Velintra knocks them both out as they begin spasming."],
      intel: ["The Wyrm says it 'used my own soul' to protect Ryo — meaning it has a soul and it chose to sacrifice part of it.", "The Wyrm taught a Domitae before Ryo — the Wyrm's fingerprint was already in Decima's family line."],
      dm: ""
    },
    {
      id: "s16", title: "Session 16 — Merchant District Ambush; O'Malley Killed; Midas at the Funeral",
      events: ["4am. Blue feather on Militarum guards at the merchant district checkpoint. Siege equipment being assembled.", "Party ambushed by the same people who attacked the militia. Attempted poisoning — everyone hit except Decima.", "O'Malley killed. Dying words: 'Premier.'", "Velintra looted O'Malley's body: Note (Westfall. Ravenscreft.), 7 gold, bloodied dagger, sealed letter, a thorn talisman.", "Lt. Boltin Crestfyre (4th Investigation Enforcement Wing) arrives on scene. Had heard the codeword 'Dagger' — now accusing the party of starting the fight.", "Midas Khol at the Duke's funeral (confirmed this session): Gave Valerian Than'dal an hourglass pendant: 'I'll keep the hourglass turning.'"],
      intel: ["Boltin heard the codeword 'Dagger' from the assassins and then used it to hold position — allowing the Consortium assassins to complete the job and flee.", "Who is 'Premier' (O'Malley's dying word)? What is in the sealed letter?"],
      dm: ""
    },
    {
      id: "s17", title: "Session 17 — Aftermath; Party Scattered; Current State",
      events: ["Consortium assassins killed O'Malley, fled with their dead, leaving no traces. Boltin Crestfyre watched without intervening before 'securing the perimeter.'", "Party surrounded by the Special Investigation Unit wanting to question under Zone of Truth or Detect Thoughts.", "Decima establishes cover: party is working with investigators, investigating disappearances (particularly Maestor Velitor), acting under Garth's and Arthur's authority."],
      intel: ["Open threads: Who is 'Premier'? What is in the sealed letter on O'Malley's body? Where did Maestor Velitor go? Who gave Boltin the compromised orders?", "The Merchant District is locked down and assembling siege equipment — what are they expecting?"],
      dm: "Current positions: Thog at Drunken Dog Inn. Kane fled. Artemis fled. Ryo hanging back. Decima near Ryo as 'Delattre.' Mithe at scene. Velintra at scene. N'thoda escaped through sewers. Aldred — location unspecified."
    },
  ],
};

// Tab labels
const TABS = ["All", "Great Houses", "Organizations", "NPCs", "Player Characters", "Locations", "Sigils", "World Lore", "Theories", "Session Notes", "Timeline"];

// App state
let currentTab = 0;
let searchTerm = "";
let expandedItems = new Set();


function init() {
  renderTabs();
  renderContent();
  setupSearch();
  setupScrollShrink();
}

// Filter on every keystroke and re-render
function setupSearch() {
  document.getElementById("search").addEventListener("input", e => {
    searchTerm = e.target.value.toLowerCase();
    renderContent();
  });
}

// Add or remove the .shrunk class based on scroll position
function setupScrollShrink() {
  const header = document.getElementById("header");
  window.addEventListener("scroll", () => {
    header.classList.toggle("shrunk", window.scrollY > 60);
  });
}

// Rebuild tab buttons, marking the currently active one
function renderTabs() {
  const container = document.getElementById("tabs");
  container.innerHTML = "";
  TABS.forEach((name, i) => {
    const btn = document.createElement("button");
    btn.className = "tab" + (currentTab === i ? " active" : "");
    btn.textContent = name;
    btn.onclick = () => {
      currentTab = i;
      expandedItems.clear();
      renderTabs();
      renderContent();
    };
    container.appendChild(btn);
  });
}

// Route to the correct render function based on active tab
function renderContent() {
  const container = document.getElementById("content");
  container.innerHTML = "";
  const renderers = [
    renderAll, renderHouses, renderOrgs, renderNPCs, renderPlayers,
    renderLocations, renderSigils, renderLore, renderTheories, renderSessions, renderTimeline,
  ];
  renderers[currentTab](container);
}

// Toggle a collapsible item open or closed then re-render
function toggleItem(id) {
  if (expandedItems.has(id)) {
    expandedItems.delete(id);
  } else {
    expandedItems.add(id);
  }
  renderContent();
}

// Check if any string field in an object matches the current search term
function matches(obj) {
  return Object.values(obj).some(v => String(v).toLowerCase().includes(searchTerm));
}


// All tab: render every section in sequence with labeled dividers
function renderAll(container) {
  renderDivider("I", "Great Houses of Avar", container);
  renderHouses(container);
  renderDivider("II", "Organizations, Orders & Factions", container);
  renderOrgs(container);
  renderDivider("III", "Non-Player Characters", container);
  renderNPCs(container);
  renderDivider("IV", "Player Characters", container);
  renderPlayers(container);
  renderDivider("V", "Locations & Map Positions", container);
  renderLocations(container);
  renderDivider("VI", "Sigils, Identifiers & Visual Markers", container);
  renderSigils(container);
  renderDivider("VII", "World Lore & Cosmology", container);
  renderLore(container);
  renderDivider("VIII", "Key Connections & Allegiance Web", container);
  renderThreads(container);
  renderDivider("IX", "World Knowledge & Player Theories", container);
  renderTheories(container);
  renderDivider("X", "Known Timeline", container);
  renderTimeline(container);
  renderDivider("XI", "Session Notes", container);
  renderSessions(container);
}

// Labeled section divider used in the All tab
function renderDivider(label, title, container) {
  const div = makeEl("div", "section-divider");
  div.appendChild(makeEl("span", "section-divider-label", label));
  div.appendChild(makeEl("span", "section-divider-rule"));
  container.appendChild(div);
  container.appendChild(makeEl("div", "section-title", title));
}


// Build and insert a collapsible accordion section into the container
// id: unique string key; label: header text; defaultOpen: initial state
function makeAccordion(id, label, container, defaultOpen = false) {
  const isOpen = defaultOpen
    ? !expandedItems.has(id + "_closed")
    : expandedItems.has(id);

  const section = makeEl("div", "accordion-section" + (isOpen ? " open" : ""));

  const toggle = makeEl("div", "accordion-header");
  toggle.innerHTML = `<span>${label}</span><span class="acc-arrow">${isOpen ? "▼" : "▶"}</span>`;
  toggle.onclick = () => {
    if (isOpen) {
      if (defaultOpen) expandedItems.add(id + "_closed");
      else expandedItems.delete(id);
    } else {
      if (defaultOpen) expandedItems.delete(id + "_closed");
      else expandedItems.add(id);
    }
    renderContent();
  };
  section.appendChild(toggle);

  container.appendChild(section);
  return { section, isOpen };
}


// Great Houses — two accordion groups with table content
function renderHouses(container) {
  const infoBox = makeEl("div", "info-box");
  infoBox.innerHTML = `<strong>⚑ The Original Twelve — What Is Known</strong><br>
    The Vo'dyn Empire was founded alongside <strong>12 Great Houses</strong> in the aftermath of the Cataclysm. Records are imprecise — DM confirmed as "9 or 11 or 12 but records are imprecise."<br><br>
    <strong>House Da'varre</strong> is <em>not</em> itself one of the original 12 — it is a <strong>cadet branch</strong> of a far more ancient house that was "mostly extinguished."<br>
    <strong>1 house was lost to time</strong> — no records, no name, no known descendants.<br>
    <strong>2 houses were expunged</strong>: one fell during the <em>Great Schism</em>; the second was erased for "direct opposition to the Church's mandate." Both bloodlines ended.`;
  container.appendChild(infoBox);

  renderHouseGroup("orig", "Original & Known Houses", data.houses.original, container, true);
  renderHouseGroup("cadet", "Cadet Branches & Post-Cataclysm Houses", data.houses.cadet, container, false);
}

function renderHouseGroup(id, label, houses, container, defaultOpen) {
  const { section, isOpen } = makeAccordion(id, label, container, defaultOpen);
  if (!isOpen) return;

  const filtered = houses.filter(matches);
  if (!filtered.length) return;

  const isOriginal = houses === data.houses.original;
  const headers = isOriginal
    ? ["House", "Circle / Reach", "Motto", "Sigil", "Power Base", "Key Members", "Disposition", "Notes"]
    : ["House", "Circle / Reach", "Sigil", "Power Base", "Key Members", "Disposition", "Notes"];

  const rows = filtered.map(h => {
    const row = [makeName(h.name), makeCircleTag(h.circle, h.circleTag)];
    if (isOriginal) row.push(makeText(h.motto));
    row.push(h.sigilTag ? makeSigilTag(h.sigil, h.sigilTag) : makeText(h.sigil));
    row.push(makeText(h.power), makeText(h.members), makeText(h.disposition), makeText(h.notes));
    return row;
  });

  const wrap = makeEl("div", "tbl-wrap");
  wrap.appendChild(buildTable(headers, rows));
  section.appendChild(wrap);
}


// Organizations — five category accordion groups
function renderOrgs(container) {
  const groups = [
    { id: "org_criminal", label: "Criminal & Underworld", items: data.orgs.criminal, open: true },
    { id: "org_military", label: "Military & Imperial Forces", items: data.orgs.military, open: false },
    { id: "org_religious", label: "Religious & Arcane Bodies", items: data.orgs.religious, open: false },
    { id: "org_paladin", label: "Paladin Orders & Covert Bodies", items: data.orgs.paladin, open: false },
    { id: "org_civil", label: "Civil & Local Bodies (Zen'tar)", items: data.orgs.civil, open: false },
  ];
  groups.forEach(g => {
    const { section, isOpen } = makeAccordion(g.id, g.label, container, g.open);
    if (!isOpen) return;
    const filtered = g.items.filter(matches);
    if (!filtered.length) return;
    const wrap = makeEl("div", "tbl-wrap");
    wrap.appendChild(buildTable(
      ["Name", "Circle / Reach", "Type", "Sigil / ID", "Key Figures", "Function & Notes"],
      filtered.map(o => [
        makeName(o.name), makeCircleTag(o.circle, o.circleTag),
        makeTypeTag(o.type, o.typeTag), makeText(o.sigil),
        makeText(o.members), makeText(o.notes),
      ])
    ));
    section.appendChild(wrap);
  });
}


// NPCs — four category accordion groups
function renderNPCs(container) {
  const groups = [
    { id: "npc_capital", label: "Capital & 1st Circle Figures", items: data.npcs.capital, open: true, type: "standard" },
    { id: "npc_zentar", label: "Zen'tar Figures (6th Circle)", items: data.npcs.zentar, open: false, type: "standard" },
    { id: "npc_historical", label: "Historical Figures & Martyrs", items: data.npcs.historical, open: false, type: "historical" },
    { id: "npc_entities", label: "Entities & Ancient Beings", items: data.npcs.entities, open: false, type: "entity" },
  ];
  groups.forEach(g => {
    const { section, isOpen } = makeAccordion(g.id, g.label, container, g.open);
    if (!isOpen) return;
    const filtered = g.items.filter(matches);
    if (!filtered.length) return;
    const wrap = makeEl("div", "tbl-wrap");
    if (g.type === "entity") {
      wrap.appendChild(buildTable(
        ["Name", "Nature", "Status", "Notes"],
        filtered.map(n => [makeName(n.name), makeText(n.nature), makeStatusTag(n.status), makeText(n.notes)])
      ));
    } else if (g.type === "historical") {
      wrap.appendChild(buildTable(
        ["Name", "Era", "Role", "Sigil / ID", "Notes"],
        filtered.map(n => [makeName(n.name), makeText(n.era), makeText(n.role), makeText(n.sigil), makeText(n.notes)])
      ));
    } else {
      wrap.appendChild(buildTable(
        ["Name", "Circle", "Role", "Allegiance", "Sigil / ID", "Status", "Notes"],
        filtered.map(n => [
          makeName(n.name),
          makeCircleTag(n.circle, n.circle.includes("1st") ? "gold" : n.circle.includes("6th") ? "blue" : "grey"),
          makeText(n.role), makeText(n.allegiance), makeText(n.sigil), makeStatusTag(n.status), makeText(n.notes),
        ])
      ));
    }
    section.appendChild(wrap);
  });
}


// Player characters — card grid with detailed bios
function renderPlayers(container) {
  const filtered = data.players.filter(matches);

  const note = makeEl("div", "possession-note");
  note.innerHTML = "<strong>Party Possession Status:</strong> Ryo (Wyrm), Decima (unknown plane entity), Aldred (demon — unaware), Kane (vampire-puppeted twin). All four are 'potential vessels' per the Warden of the Deep.";
  container.appendChild(note);

  const grid = makeEl("div", "player-grid");
  filtered.forEach(p => {
    const card = makeEl("div", "player-card");

    const nameRow = makeEl("div", "player-name-row");
    nameRow.appendChild(makeEl("h3", "player-name", p.name));
    const echo = makeEl("span", "player-echo", p.echo);
    echo.style.background = p.echoBg || "#8b1a1a";
    nameRow.appendChild(echo);
    card.appendChild(nameRow);

    card.appendChild(makeEl("div", "player-meta", `${p.race} · ${p.cls} · Age ${p.age} · ${p.height} | ${p.origin}`));
    if (p.appearance) card.appendChild(makeEl("div", "player-appearance", p.appearance));
    card.appendChild(makeEl("p", "player-bio", p.bio));
    card.appendChild(makeEl("div", "field-label", "Connections"));
    card.appendChild(makeEl("div", "field-value", p.connections));

    grid.appendChild(card);
  });
  container.appendChild(grid);
}


// Locations — two accordion groups
function renderLocations(container) {
  const groups = [
    { id: "loc_zentar", label: "Zen'tar — Key Districts & Sites", items: data.locations.zentar, open: true, key: "zone" },
    { id: "loc_empire", label: "Broader Avar — Empire & Beyond", items: data.locations.empire, open: false, key: "circle" },
  ];
  groups.forEach(g => {
    const { section, isOpen } = makeAccordion(g.id, g.label, container, g.open);
    if (!isOpen) return;
    const filtered = g.items.filter(matches);
    if (!filtered.length) return;
    const wrap = makeEl("div", "tbl-wrap");
    const colLabel = g.key === "zone" ? "District / Zone" : "Circle";
    wrap.appendChild(buildTable(
      ["Location", colLabel, "Controller", "Key Notes"],
      filtered.map(l => [makeName(l.name), makeText(l[g.key]), makeText(l.controller), makeText(l.notes)])
    ));
    section.appendChild(wrap);
  });
}


// Sigils — two accordion groups
function renderSigils(container) {
  // Confirmed faction sigils
  const { section: s1, isOpen: o1 } = makeAccordion("sig_confirmed", "Confirmed Sigils & Faction Markers", container, true);
  if (o1) {
    const filtered = data.sigils.confirmed.filter(matches);
    if (filtered.length) {
      const wrap = makeEl("div", "tbl-wrap");
      wrap.appendChild(buildTable(
        ["Sigil / Marker", "Associated With", "Circle", "Where Seen", "Significance"],
        filtered.map(s => [makeName(s.sigil), makeText(s.assoc), makeText(s.circle), makeText(s.seen), makeText(s.meaning)])
      ));
      s1.appendChild(wrap);
    }
  }

  // Meteorite chamber symbols and armband hierarchy
  const { section: s2, isOpen: o2 } = makeAccordion("sig_chamber", "Meteorite Chamber Symbols & Armband Hierarchy", container, false);
  if (o2) {
    const mf = data.sigils.meteorite.filter(matches);
    if (mf.length) {
      s2.appendChild(makeEl("div", "sub-section-label", "Chamber Symbols"));
      const wrap1 = makeEl("div", "tbl-wrap");
      wrap1.appendChild(buildTable(
        ["Symbol", "Location", "Meaning / Label"],
        mf.map(s => [makeName(s.marker), makeText(s.location), makeText(s.meaning)])
      ));
      s2.appendChild(wrap1);
    }
    const af = data.sigils.armbands.filter(matches);
    if (af.length) {
      s2.appendChild(makeEl("div", "sub-section-label", "Armband Color Hierarchy"));
      const wrap2 = makeEl("div", "tbl-wrap");
      wrap2.appendChild(buildTable(
        ["Armband Color", "Location", "Affiliation / Rank"],
        af.map(s => [makeName(s.color), makeText(s.location), makeText(s.affil)])
      ));
      s2.appendChild(wrap2);
    }
  }
}


// World lore — wound/veils table, confirmed facts table, then active threads
function renderLore(container) {
  // Wound, veils, and the machines table
  const { section: s1, isOpen: o1 } = makeAccordion("lore_main", "The Wound, The Veils & The Machines", container, true);
  if (o1) {
    const filtered = data.lore.filter(matches);
    if (filtered.length) {
      const wrap = makeEl("div", "tbl-wrap");
      wrap.appendChild(buildTable(
        ["Concept", "Nature", "Connection", "Current Status"],
        filtered.map(l => [makeName(l.concept), makeText(l.nature), makeText(l.connection), makeText(l.status)])
      ));
      s1.appendChild(wrap);
    }
  }

  // DM confirmed facts about the empire and lore
  const { section: s2, isOpen: o2 } = makeAccordion("lore_conf", "The Empire, Religion & Runes — DM Confirmed", container, false);
  if (o2) {
    const facts = [
      { topic: "Circle Structure", fact: "Vo'dyn Empire: ~9-11 concentric circles. 1st = Capital (Kholinar). 2nd = Religious sector. 3rd = Significant nobles/advisors. 4th = Upper merchant class. 6th = Zen'tar (sub-capital). 10th = Banmore Keep." },
      { topic: "House Mournen's Circle", fact: "DM: 'While the city is in the outer edges (6th-ish circle), given its historical and material significance the noble house governing it has quite an odd influence designation. They were prevalent in the capital... and have always had some level of significance in capital politics.'" },
      { topic: "Runes", fact: "DM: 'Runes are reactive, not active... Think of them as transistors.' Rune A will always do the same thing given the same stimulus. 'You can't just copy a rune 1:1 with a sketch on a canvas — that won't produce an effect.'" },
      { topic: "The Ledger / Factions", fact: "DM: 'There are some simply vying for control of Zentar, the 6th circle, after the Duke's death. And some additionally knowledgeable of the more historical and magical pieces of info, and vying for control of the Ledger that was last known to be with the Duke.'" },
      { topic: "The Campaign Theme", fact: "DM (Session 0): 'You are all in a remnant of a decaying empire continuously losing its border skirmishes. And the only faith that exists is religious fervor. And the fact magic / tech is starting to innovate again.'" },
      { topic: "Medicine & Entropy", fact: "DM: 'No cure, but there are different ailments and treatments. Exposure leads to entropic decay of who you are.' (Re: Lux's death from Flux exposure.)" },
    ].filter(matches);

    if (facts.length) {
      const wrap = makeEl("div", "tbl-wrap");
      wrap.appendChild(buildTable(
        ["Topic", "Confirmed Fact (DM)"],
        facts.map(f => [makeName(f.topic), makeText(f.fact)])
      ));
      s2.appendChild(wrap);
    }
  }

  // Active plot threads shown at the bottom of the lore tab
  container.appendChild(makeEl("div", "section-title", "Key Connections & Allegiance Web"));
  renderThreads(container);
}

// Active plot threads as a two-column card grid
function renderThreads(container) {
  const filtered = data.threads.filter(matches);
  const grid = makeEl("div", "thread-grid");
  filtered.forEach(t => {
    const card = makeEl("div", "thread-card");
    card.appendChild(makeEl("h3", "thread-title", t.title));
    card.appendChild(makeEl("div", "thread-status", t.status));
    card.appendChild(makeEl("p", "thread-detail", t.detail));
    grid.appendChild(card);
  });
  container.appendChild(grid);
}


// Theories — DM confirmed first, then player theories
function renderTheories(container) {
  container.appendChild(makeEl("div", "theories-warning",
    "⚑ Entries marked DM CONFIRMED reflect information explicitly provided by the DM. All other analysis and interpretations are player theories unless otherwise stated."));

  const filtered = data.theories.filter(matches);
  const confirmed = filtered.filter(t => t.confirmed);
  const player = filtered.filter(t => !t.confirmed);

  if (confirmed.length) {
    container.appendChild(makeEl("div", "sub-section-label", "DM Confirmed"));
    confirmed.forEach(t => {
      const card = makeEl("div", "theory-card confirmed-card");
      const label = makeEl("div", "theory-label");
      label.innerHTML = `<span class="confirmed-badge">DM CONFIRMED</span> ${t.label}`;
      card.appendChild(label);
      card.appendChild(makeEl("div", "theory-detail", t.detail));
      container.appendChild(card);
    });
  }

  if (player.length) {
    container.appendChild(makeEl("div", "sub-section-label", "Player Theories"));
    player.forEach(t => {
      const card = makeEl("div", "theory-card");
      card.appendChild(makeEl("div", "theory-label", t.label));
      card.appendChild(makeEl("div", "theory-detail", t.detail));
      container.appendChild(card);
    });
  }
}


// Session notes — one collapsible block per session
function renderSessions(container) {
  container.appendChild(makeEl("div", "theories-warning",
    "⚑ Unless a note is explicitly attributed to the DM, all theories, interpretations, and analytical commentary are player theories — not confirmed lore."));

  const filtered = data.sessions.filter(s =>
    !searchTerm || [s.title, ...(s.events || []), ...(s.intel || []), s.dm || ""].join(" ").toLowerCase().includes(searchTerm)
  );

  filtered.forEach(s => {
    const isOpen = expandedItems.has(s.id);
    const block = makeEl("div", "session-block" + (isOpen ? " open" : ""));

    const toggle = makeEl("div", "session-toggle");
    toggle.innerHTML = `<span>${s.title}</span><span class="acc-arrow">${isOpen ? "▼" : "▶"}</span>`;
    toggle.onclick = () => toggleItem(s.id);
    block.appendChild(toggle);

    if (isOpen) {
      const body = makeEl("div", "session-body");

      if (s.events && s.events.length) {
        body.appendChild(makeEl("div", "session-sub", "Key Events"));
        const ul = makeEl("ul", "session-list");
        s.events.forEach(e => ul.appendChild(makeEl("li", "", e)));
        body.appendChild(ul);
      }

      if (s.intel && s.intel.length) {
        body.appendChild(makeEl("div", "session-sub", "Observations & Intel"));
        const ul = makeEl("ul", "session-list");
        s.intel.forEach(e => ul.appendChild(makeEl("li", "", e)));
        body.appendChild(ul);
      }

      if (s.dm) {
        body.appendChild(makeEl("div", "session-dm", "DM: " + s.dm));
      }

      block.appendChild(body);
    }
    container.appendChild(block);
  });
}


// Timeline — single collapsible table
function renderTimeline(container) {
  const { section, isOpen } = makeAccordion("timeline_main", "Timeline — Pre-Cataclysm to Present", container, true);
  if (!isOpen) return;

  const filtered = data.timeline.filter(matches);
  if (!filtered.length) return;

  const wrap = makeEl("div", "tbl-wrap");
  wrap.appendChild(buildTable(
    ["Approx. Year", "Event"],
    filtered.map(t => [makeName(t.era), makeText(t.event)])
  ));
  section.appendChild(wrap);
}


// Build a generic table from header strings and pre-built cell elements
function buildTable(headers, rows) {
  const table = document.createElement("table");

  const thead = document.createElement("thead");
  const headerRow = document.createElement("tr");
  headers.forEach(h => {
    const th = document.createElement("th");
    th.textContent = h;
    headerRow.appendChild(th);
  });
  thead.appendChild(headerRow);
  table.appendChild(thead);

  const tbody = document.createElement("tbody");
  rows.forEach(cells => {
    const tr = document.createElement("tr");
    cells.forEach(cell => {
      const td = document.createElement("td");
      if (cell && typeof cell === "object" && cell.nodeType) {
        td.appendChild(cell);
      } else {
        td.textContent = cell || "—";
      }
      tr.appendChild(td);
    });
    tbody.appendChild(tr);
  });
  table.appendChild(tbody);
  return table;
}

// Plain text cell element
function makeText(text) {
  const span = document.createElement("span");
  span.className = "cell-text";
  span.textContent = text || "—";
  return span;
}

// Bold name element for first-column table cells
function makeName(text) {
  const span = document.createElement("span");
  span.className = "cell-name";
  span.textContent = text || "—";
  return span;
}

// Circle-tier tag colored by type: gold = 1st circle, blue = outer circles, grey = unknown, red = expunged
function makeCircleTag(text, type) {
  const span = document.createElement("span");
  span.className = "tag tag-" + (type || "grey");
  span.textContent = text || "—";
  return span;
}

// Sigil tag colored by importance type
function makeSigilTag(text, type) {
  const span = document.createElement("span");
  span.className = "tag tag-" + (type || "grey");
  span.textContent = text || "—";
  return span;
}

// Organization type tag colored by category
function makeTypeTag(text, type) {
  const span = document.createElement("span");
  span.className = "tag tag-" + (type || "grey");
  span.textContent = text || "—";
  return span;
}

// Status tag colored by the content of the status text
function makeStatusTag(text) {
  if (!text) return makeText("—");
  const span = document.createElement("span");
  span.className = "status-tag";
  const s = text.toLowerCase();
  let color = "#c4bfb0";
  if (s.includes("dead") || s.includes("deceased")) color = "#e88";
  else if (s.includes("missing") || s.includes("disappear")) color = "#d4a843";
  else if (s.includes("suspicious") || s.includes("unknown")) color = "#c8843a";
  else if (s.includes("alive") || s.includes("active")) color = "#8c8";
  span.style.color = color;
  span.style.borderColor = color;
  span.textContent = text;
  return span;
}

// Create an element with a class and optional text content
function makeEl(tag, className, text) {
  const el = document.createElement(tag);
  if (className) el.className = className;
  if (text !== undefined) el.textContent = text;
  return el;
}

document.addEventListener("DOMContentLoaded", init);
